import matlab.engine

def main():
    eng = matlab.engine.start_matlab()

    # Define audio file paths
    file_paths = ['BASF 4-1 TMS.wav', 'N01 A TMS.wav', 'TMS from Compilation A.wav', 'TMS-new 32-bit PCM.wav']
    target_sr = 44100
    lowcut = 48
    highcut = 52

    print("Starting MATLAB processing...\n")

    signals = []
    for path in file_paths:
        print(f"Loading and resampling {path}\n")
        signal, sr = eng.audioread(path, nargout=2)
        signal = eng.resample(signal, target_sr, sr, nargout=1)

        # Apply Butterworth bandpass filter
        low_norm = lowcut / (target_sr / 2)
        high_norm = highcut / (target_sr / 2)
        wn = matlab.double([low_norm, high_norm])
        print(f"Applying Butterworth bandpass filter from {lowcut} Hz to {highcut} Hz\n")
        b, a = eng.butter(5, wn, 'bandpass', nargout=2)
        filtered_signal = eng.filter(b, a, signal, nargout=1)

        # Convert from cell to numeric array if necessary
        if eng.iscell(filtered_signal):
            print("Converting filtered signal from cell to numeric array.\n")
            filtered_signal = eng.cell2mat(filtered_signal)

        # Ensure the signal is a single-row vector
        filtered_signal = eng.reshape(filtered_signal, [1, eng.numel(filtered_signal)], nargout=1)
        
        signals.append(filtered_signal)

    # Normalize and cross-correlate signals
    aligned_signals = []
    for signal in signals:
        aligned_signals.append(eng.squeeze(signal))  # Squeeze to ensure it's a vector

    # Perform cross-correlation and alignment
    for i in range(1, len(aligned_signals)):
        print(f"Cross-correlating and aligning signal {i+1} with signal 1\n")
        correlation, lags = eng.xcorr(aligned_signals[0], aligned_signals[i], 'coeff', 'none', nargout=2)
        lag = lags[eng.find(correlation == eng.max(correlation), nargout=1)[0]]
        aligned_signals[i] = eng.circshift(aligned_signals[i], -int(lag), nargout=1)

    # Combine signals by averaging
    combined_signal = eng.mean(matlab.double(aligned_signals), 2, nargout=1)

    # Plotting and saving results
    print("Plotting and saving results\n")
    for i, signal in enumerate(aligned_signals + [combined_signal], 1):
        eng.figure(nargout=0)
        eng.plot(signal, nargout=0)
        eng.title(f'Signal {i}', nargout=0)
        eng.xlabel('Samples', nargout=0)
        eng.ylabel('Amplitude', nargout=0)
        eng.savefig(f'signal_{i}.fig', nargout=0)
        eng.savefig(f'signal_{i}.png', nargout=0)

    # Save the final combined signal
    output_path = 'combined_signal.wav'
    eng.audiowrite(output_path, combined_signal, target_sr, nargout=0)
    print(f"Combined signal saved as {output_path}\n")

    print("MATLAB processing complete.\n")
    eng.quit()

if __name__ == '__main__':
    main()
