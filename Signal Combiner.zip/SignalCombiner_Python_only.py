import numpy as np
import matplotlib.pyplot as plt
import librosa
import scipy.signal
import soundfile as sf

def load_and_resample(file_path, target_sr=44100):
    print(f"Loading and resampling {file_path}\n")
    signal, sr = librosa.load(file_path, sr=None)
    if sr != target_sr:
        signal = librosa.resample(signal, orig_sr=sr, target_sr=target_sr)
    print(f"Loaded {file_path} with original SR={sr}, resampled to {target_sr}\n")
    return signal, target_sr

def bandpass_filter(signal, sr, lowcut=48, highcut=52):
    print(f"Applying bandpass filter from {lowcut} Hz to {highcut} Hz\n")
    sos = scipy.signal.butter(10, [lowcut, highcut], btype='bandpass', fs=sr, output='sos')
    filtered_signal = scipy.signal.sosfilt(sos, signal)
    print(f"Filter applied: Bandpass from {lowcut} to {highcut} Hz\n")
    return filtered_signal

def cross_correlation(x, y):
    """ Cross-correlate two signals and find the lag that maximizes the correlation. """
    print("Calculating cross-correlation\n")
    correlation = np.correlate(x, y, mode='full')
    lag = np.argmax(correlation) - (len(x) - 1)
    print(f"Cross-correlation calculated, lag={lag}\n")
    return correlation, lag

def align_signals(signals, file_paths, sr):
    """ Align signals using cross-correlation, assuming signals[0] is the reference. """
    aligned_signals = [signals[0]]
    plt.figure(figsize=(10, len(signals) * 2))
    
    for i, signal in enumerate(signals[1:], 1):
        print(f"Aligning {file_paths[i]} against {file_paths[0]}\n")
        correlation, lag = cross_correlation(signals[0], signal)
        plt.subplot(len(signals) - 1, 1, i)
        plt.plot(correlation)
        plt.title(f"Cross-Correlation {file_paths[0]} vs {file_paths[i]}")
        plt.xlabel('Lag')
        plt.ylabel('Correlation')
        if lag > 0:
            aligned_signal = np.pad(signal, (lag, 0), mode='constant', constant_values=(0, 0))[:len(signal)]
        else:
            aligned_signal = np.pad(signal, (0, -lag), mode='constant', constant_values=(0, 0))
        aligned_signals.append(aligned_signal)
        print(f"{file_paths[i]} aligned with a lag of {lag} samples\n")
    
    plt.tight_layout()
    plt.show(block=False)  # Modified to allow non-blocking display
    plt.pause(0.001)  # Pause to ensure that the plot updates are displayed properly
    return aligned_signals

def plot_signals(signals, sr, file_paths, title='Signal Waveforms'):
    print(f"Plotting {title}\n")
    plt.figure(figsize=(10, 6))
    for signal, path in zip(signals, file_paths):
        time = np.linspace(0, len(signal) / sr, num=len(signal))
        plt.plot(time, signal, linewidth=1)
    plt.title(title)
    plt.xlabel('Time (seconds)')
    plt.ylabel('Amplitude')
    plt.legend([path for path in file_paths])
    plt.show(block=False)  # Modified to allow non-blocking display
    plt.pause(0.001)  # Pause to ensure that the plot updates are displayed properly

def main():
    file_paths = ['BASF 4-1 TMS.wav', 'N01 A TMS.wav', 'TMS from Compilation A.wav', 'TMS-new 32-bit PCM.wav']
    signals = []
    sr = 44100  # Define a common sampling rate
    print("Starting processing of audio files\n")
    
    for path in file_paths:
        signal, sr = load_and_resample(path, target_sr=sr)
        filtered_signal = bandpass_filter(signal, sr)
        signals.append(filtered_signal)
    
    plot_signals(signals, sr, file_paths, title='Filtered Signals Before Alignment')

    aligned_signals = align_signals(signals, file_paths, sr)

    plot_signals(aligned_signals, sr, file_paths, title='Filtered Signals After Alignment')

    print("Combining signals by averaging\n")
    combined_signal = np.mean(aligned_signals, axis=0)

    plot_signals([combined_signal], sr, ['Combined Signal'], title='Combined Signal')

    output_path = 'combined_signal.wav'
    sf.write(output_path, combined_signal, sr)
    print(f"Combined signal saved as {output_path}\n")

if __name__ == '__main__':
    main()
