import numpy as np
import matplotlib.pyplot as plt
import librosa
import scipy.signal
import soundfile as sf

def load_and_resample(file_path, target_sr=44100):
    signal, sr = librosa.load(file_path, sr=None)
    if sr != target_sr:
        signal = librosa.resample(signal, orig_sr=sr, target_sr=target_sr)
    return signal, target_sr

def bandpass_filter(signal, sr, lowcut=48, highcut=52):
    sos = scipy.signal.butter(10, [lowcut, highcut], btype='bandpass', fs=sr, output='sos')
    filtered_signal = scipy.signal.sosfilt(sos, signal)
    return filtered_signal

def cross_correlation(x, y):
    """ Cross-correlate two signals and find the lag that maximizes the correlation. """
    correlation = np.correlate(x, y, mode='full')
    lag = np.argmax(correlation) - (len(x) - 1)
    return lag

def align_signals(signals):
    """ Align signals using cross-correlation, assuming signals[0] is the reference. """
    aligned_signals = [signals[0]]
    for signal in signals[1:]:
        lag = cross_correlation(signals[0], signal)
        if lag > 0:
            aligned_signal = np.pad(signal, (lag, 0), mode='constant', constant_values=(0, 0))[:len(signal)]
        else:
            aligned_signal = np.pad(signal, (0, -lag), mode='constant', constant_values=(0, 0))
        aligned_signals.append(aligned_signal)
    return aligned_signals

def plot_signals(signals, sr, title='Signal Waveforms', legend_prefix='Signal'):
    plt.figure(figsize=(10, 6))
    for signal in signals:
        time = np.linspace(0, len(signal) / sr, num=len(signal))
        plt.plot(time, signal, linewidth=1)
    plt.title(title)
    plt.xlabel('Time (seconds)')
    plt.ylabel('Amplitude')
    plt.legend([legend_prefix + ' ' + str(i+1) for i in range(len(signals))])
    plt.show()

def main():
    # Adjust these file paths to your audio files
    file_paths = ['BASF 4-1 TMS.wav', 'N01 A TMS.wav', 'TMS from Compilation A.wav', 'TMS-new 32-bit PCM.wav']
    signals = []
    sr = 44100  # Define a common sampling rate
    
    for path in file_paths:
        signal, sr = load_and_resample(path, target_sr=sr)
        filtered_signal = bandpass_filter(signal, sr)
        signals.append(filtered_signal)
    
    # Plot before alignment
    plot_signals(signals, sr, title='Filtered Signals Before Alignment')

    # Align signals
    aligned_signals = align_signals(signals)

    # Plot after alignment
    plot_signals(aligned_signals, sr, title='Filtered Signals After Alignment')

    # Combine signals by averaging
    combined_signal = np.mean(aligned_signals, axis=0)

    # Plot combined signal
    plot_signals([combined_signal], sr, title='Combined Signal', legend_prefix='Combined')

if __name__ == '__main__':
    main()
