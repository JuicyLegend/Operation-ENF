import matlab.engine

def main():
    eng = matlab.engine.start_matlab()
    
    # Define audio file paths
    file_paths = ['BASF 4-1 TMS.wav', 'N01 A TMS.wav', 'TMS from Compilation A.wav', 'TMS-new 32-bit PCM.wav']
    target_sr = 44100
    lowcut = 48
    highcut = 52

    print("Starting MATLAB processing...\n")

    # # Load and filter signals
    # signals = []
    # for path in file_paths:
    #     print(f"Loading and resampling {path}\n")
    #     signal, sr = eng.audioread(path, nargout=2)
    #     signal = eng.resample(signal, target_sr, sr, nargout=1)  # Resample to target_sr
    #     print(f"Applying Butterworth bandpass filter from {lowcut} Hz to {highcut} Hz\n")
    #     b, a = eng.butter(5, [lowcut/(target_sr/2), highcut/(target_sr/2)], 'bandpass', nargout=2)
    #     filtered_signal = eng.filter(b, a, signal, nargout=1)
    #     signals.append(filtered_signal)

    # Load and filter signals
    signals = []
    for path in file_paths:
        print(f"Loading and resampling {path}\n")
        signal, sr = eng.audioread(path, nargout=2)
        signal = eng.resample(signal, target_sr, sr, nargout=1)  # Resample to target_sr

        # Calculate normalized frequency range for Butterworth filter
        low_norm = lowcut / (target_sr / 2)
        high_norm = highcut / (target_sr / 2)

        # Convert frequency range to MATLAB double type
        wn = matlab.double([low_norm, high_norm])

        print(f"Applying Butterworth bandpass filter from {lowcut} Hz to {highcut} Hz\n")
        b, a = eng.butter(5, wn, 'bandpass', nargout=2)
        filtered_signal = eng.filter(b, a, signal, nargout=1)
        signals.append(filtered_signal)

    # Align signals using cross-correlation
    aligned_signals = [signals[0]]
    for i, signal in enumerate(signals[1:], 1):
        print(f"Cross-correlating and aligning signal {i+1} with signal 1\n")
        correlation = eng.xcorr(signals[0], signal, 'coeff', nargout=1)
        lag = eng.find(correlation == eng.max(correlation), nargout=1)
        lag = lag[0] - len(signal)  # MATLAB index to Python index
        aligned_signal = eng.circshift(signal, (1, int(lag) - len(signal)//2))
        aligned_signals.append(aligned_signal)
    
    # Combine signals by averaging
    combined_signal = eng.mean(matlab.double(aligned_signals), 2, nargout=1)

    # Plotting and saving plots
    print("Plotting and saving results\n")
    for i, signal in enumerate(aligned_signals + [combined_signal], 1):
        eng.figure(nargout=0)
        eng.plot(signal, nargout=0)
        eng.title(f'Signal {i}', nargout=0)
        eng.xlabel('Samples', nargout=0)
        eng.ylabel('Amplitude', nargout=0)
        eng.savefig(f'signal_{i}.fig', nargout=0)
        eng.saveas(f'signal_{i}.png', nargout=0)
        print(f"Signal {i} plot saved as signal_{i}.fig\n")

    # Save the final combined signal to a new WAV file
    output_path = 'combined_signal.wav'
    eng.audiowrite(output_path, combined_signal, target_sr, nargout=0)
    print(f"Combined signal saved as {output_path}\n")

    print("MATLAB processing complete.\n")
    eng.quit()

if __name__ == '__main__':
    main()
